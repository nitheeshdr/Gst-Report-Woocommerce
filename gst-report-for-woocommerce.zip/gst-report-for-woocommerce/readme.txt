=== GST Report for WooCommerce ===
Contributors: nitheeshdr
Tags: woocommerce, gst, india, tax, invoice
Requires at least: 5.9
Tested up to: 6.9
Stable tag: 2.0.1
Requires PHP: 7.4
WC requires at least: 5.0
WC tested up to: 9.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A native PHP GST dashboard for WooCommerce — CGST/SGST/IGST breakdown, Excel export, and tax invoices. No JavaScript frameworks, no REST API.

== Description ==

**GST Report for WooCommerce** is a lightweight admin dashboard built entirely with native PHP and direct database queries. It generates GST-compliant reports for Indian WooCommerce stores, handles both intra-state (CGST + SGST) and inter-state (IGST) tax calculations, and lets you export to Excel or download individual tax invoices in one click.

= Key Features =

* **GST Report tab** — Line-item breakdown per order with CGST/SGST (intra-state, Tamil Nadu) and IGST (inter-state), at both 18% and 5% GST rates plus zero-rated supply.
* **Orders tab** — Card-based order view showing customer details, GSTIN, order status, and a per-order GST breakdown.
* **Products tab** — All published products with SKU, HSN code, price, stock, and GST rate at a glance.
* **Excel export** — Download filtered data as a properly formatted `.xlsx` file using a zero-dependency PHP writer.
* **Tax invoice download** — Generate and download an HTML tax invoice for any order, including CGST/SGST/IGST line items and billing/shipping addresses.
* **Flexible HSN lookup** — Reads HSN from product meta (`hsn`, `_hsn_code`), product attributes, or order-item meta — whichever is present.
* **HPOS compatible** — Works with both the classic `wp_posts` order table and WooCommerce High-Performance Order Storage (HPOS).
* **Filtering & pagination** — Filter by date range, sort newest/oldest, search by order ID or billing email, 50 orders per page.
* **Summary stats** — At-a-glance cards for total orders, total products, revenue, total GST collected, and average order value.

= Who is this for? =

Indian WooCommerce store owners who need to file GST returns (GSTR-1, GSTR-3B) and want a clean, fast dashboard inside WordPress without installing a heavy accounting plugin.

= Technical Notes =

* No JavaScript frameworks — pure PHP rendered HTML.
* No REST API calls — all data fetched via `WC_Order_Query` and direct SQL aggregation.
* All user input is sanitised with WordPress functions (`sanitize_key`, `sanitize_text_field`, `absint`).
* All database queries use `$wpdb->prepare()`.
* All output is escaped with `esc_html()`, `esc_url()`, `esc_attr()`.
* Nonce-protected for all export and invoice download actions.

== Installation ==

1. Upload the `gst-report-plugin` folder to the `/wp-content/plugins/` directory, or install the plugin directly through the WordPress **Plugins > Add New** screen.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Go to **GST Report** in the WordPress admin sidebar.
4. Make sure your products have an HSN code stored in the `hsn` or `_hsn_code` product meta field, or as a product attribute.

= Requirements =

* WordPress 5.9 or higher
* WooCommerce 5.0 or higher
* PHP 7.4 or higher
* WooCommerce tax rates configured with appropriate tax classes (use a tax class name containing `5` for 5% GST items; the default tax class is treated as 18%)

== Frequently Asked Questions ==

= How does the plugin determine CGST/SGST vs IGST? =

The plugin reads the billing state of each order. If the billing state is **TN** (Tamil Nadu), it splits the tax as CGST + SGST (intra-state). All other states are treated as IGST (inter-state). This logic can be extended for other home states by modifying the `is_tn()` method in `class-gst-calculator.php`.

= How do I set the HSN code for my products? =

Go to **Products > Edit Product** and add a custom field with the key `hsn` (or `_hsn_code`) and the HSN code as the value. You can also use a product attribute named anything containing "HSN" (e.g., "HSN Code", "HSN/SAC").

= How do I mark a product as 5% GST? =

Assign a WooCommerce tax class whose name contains `5` (e.g., "GST 5%", "5-percent") to the product. All other tax classes (including the default) are treated as 18% GST.

= Does the plugin support WooCommerce HPOS? =

Yes. The plugin automatically detects whether HPOS is enabled and switches its SQL aggregation query between the `wc_orders` table (HPOS) and the classic `wp_posts` / `wp_postmeta` tables.

= Can I filter the Excel export by date? =

Yes. Apply the date filters on the GST Report page first, then click **Export Excel**. The exported file will contain only the filtered orders.

= What format is the invoice download? =

Invoices are downloaded as `.html` files that you can open in any browser and print or save as PDF.

= Does this work with variable products? =

Yes. HSN lookup checks the variation first (more specific), then falls back to the parent product.

== Screenshots ==

1. GST Report tab — line-item breakdown with CGST/SGST/IGST columns.
2. Orders tab — card-based view with GST breakdown per order.
3. Products tab — product list with HSN code and GST rate.
4. Summary stat cards at the top of the dashboard.
5. Sample tax invoice download.

== Changelog ==

= 2.0.1 =
* Fixed: escape `$class` variable in tab navigation with `esc_attr()`.
* Fixed: wrap `paginate_links()` output with `wp_kses_post()`.
* Fixed: replaced `date()` with `wp_date()` for timezone-safe filename generation.
* Fixed: replaced `tempnam()` with `wp_tempnam()` and `unlink()` with `wp_delete_file()`.
* Fixed: added `wp_unslash()` to all `$_GET` reads before sanitization.
* Fixed: added result caching to stats SQL query via `wp_cache_get/set`.
* Fixed: reduced plugin tags to the allowed maximum of 5.
* Fixed: version bumped to 2.0.1.

= 2.0.0 =
* Complete rewrite — native PHP, direct DB queries, no JavaScript frameworks.
* Added HPOS (High-Performance Order Storage) compatibility.
* Added 5% GST rate support alongside 18%.
* Added per-order invoice download.
* Added Products tab with HSN and GST rate display.
* Added Excel (.xlsx) export using a zero-dependency PHP writer.
* Improved HSN lookup: checks variation, parent product, attributes, and order-item meta.
* Added SQL-based stats aggregation (no N+1 queries).
* Nonce protection on all export and download actions.

== Upgrade Notice ==

= 2.0.0 =
Full rewrite. Deactivate and reactivate the plugin after upgrading.
